package com.example.segundaevaluacion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val codigo3 = findViewById<TextView>(R.id.pag3Codigo)
        val codigopag3:String = intent.extras?.getString("Codigo").orEmpty()
        val descripcion3 = findViewById<TextView>(R.id.pag3Descripcion)
        val descripcionpag3:String = intent.extras?.getString("Descripcion").orEmpty()




    }
}