package com.example.segundaevaluacion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val codigo1 = findViewById<EditText>(R.id.pag1Codigo)
        val descripcion1 = findViewById<EditText>(R.id.pag1Descripcion)

        val precio1 = findViewById<EditText>(R.id.pag1Precio)
        val botonCrear1pag2 = findViewById<Button>(R.id.pag1BotonCrear)

        botonCrear1pag2.setOnClickListener{
        val accion = intent(this.MainActivity2::class.java)
            accion.putExtra("Codigo",codigo1.text.toString(),"Descripcion",descripcion1.text.toString(),
            "Precio",precio1.text.toString())
            startActivity(accion)}



    }


    }

