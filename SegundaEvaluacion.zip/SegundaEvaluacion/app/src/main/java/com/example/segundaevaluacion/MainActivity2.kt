package com.example.segundaevaluacion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val codigo2 = findViewById<TextView>(R.id.pag2Codigo)
        val codigopag2:String = intent.extras?.getString("Codigo").orEmpty()
        val descripcion2 = findViewById<TextView>(R.id.pag2Descipcion)
        val descripcionpag2:String = intent.extras?.getString("Descripcion").orEmpty()
        val precio2 = findViewById<TextView>(R.id.pag2Precio)
        val preciopag2:String = intent.extras?.getString("Precio").orEmpty()

        var diaspvencer = findViewById<TextView>(R.id.pag2DiasparaVencer)


        var Nuevovalor = findViewById<TextView>(R.id.pag2NuevoValor)
        var perecible =  findViewById<TextView>(R.id.pag2DiasparaVencer)
        }

     fun divicion(num1:Double, num2:Double){
            when (diaspvencer) {
                1 -> {
                    divicion(precio2/4)
                }
                2 -> {
                    divicion(precio2/3)
                }
                3 -> {
                    divicion(precio2/2)
                }
            }
        }

    private fun divicion(num1: Double) {}

    }




